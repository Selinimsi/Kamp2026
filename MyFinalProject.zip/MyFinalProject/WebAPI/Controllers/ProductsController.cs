﻿using Busniess.Abstract;
using Busniess.Concrete;
using DataAccess.Concrete.EntitiyFrameWork;
using Entities.Concreate;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]//Attribute yani bu bir imza .Net e bu bir controller demiş oluyoruz
    public class ProductsController : ControllerBase
    {
        [HttpGet]
        public List<Product> Get()
        {
            IProductService productService=new ProductManager(new EfProductDal());
            var result =productService.GetAll();
            return result.Message;
        }
    }
}
