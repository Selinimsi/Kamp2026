﻿using Core.Utilities.Conreate.Result;
using Core.Utilities.Results.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Utilities.Results.Concreate
{
    public class DataResult<T> : Result, IDataResult<T>
    {
        public DataResult(T data,bool success,string message):base(success,message)
        {
                Message = data;
        }
        public DataResult(T data, bool success) : base(success)
        {
            Message = data;
        }
        public T Message { get; }
    }
}
